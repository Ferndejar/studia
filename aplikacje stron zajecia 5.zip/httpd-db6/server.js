var fs = require('fs');
var http = require('http');
var path = require('path');
var mime = require('mime');

var debugLog = true;
var initDB = true; // set to false to suppress DB initialization

function serveFile(rep, fileName, errorCode, message) {
	
	if(debugLog) console.log('Serving file ' + fileName + (message ? ' with message \'' + message + '\'': ''));
	
    fs.readFile(fileName, function(err, data) {
		if(err) {
            serveError(rep, 404, 'Document ' + fileName + ' not found');
        } else {
			rep.writeHead(errorCode, message, { 'Content-Type': mime.getType(path.basename(fileName)) });
			if(message) {
				data = data.toString().replace('{errMsg}', rep.statusMessage).replace('{errCode}', rep.statusCode);
			}
			rep.end(data);
        }
      });
}

if(!debugLog) process.on('uncaughtException', function (err) {
	console.log('\nRUNTIME ERROR\n\n' + err + '\n\nexiting...');
	process.exit(1);
});

function serveError(rep, error, message) {
	serveFile(rep, 'html/error.html', error, message);
}

var db = require('./db.js');

if(initDB) {
	require('./initialize.js');
}

var listeningPort = 8888;

http.createServer().on('request', function (req, rep) {
	
	if(debugLog) console.log('HTTP request URL: ' + req.url);
	
	switch(req.url) {
		case '/':
			serveFile(rep, 'html/index.html', 200, '');
			break;
		case '/favicon.ico':
			serveFile(rep, 'img/favicon.ico', 200, '');
			break;
		default:
			if(/^\/(html|css|js|fonts|img)\//.test(req.url)) {
				var fileName = path.normalize('./' + req.url)
				serveFile(rep, fileName, 200, '');
			} else if(/^\/db\//.test(req.url)) {
					var args = req.url.split("/").slice(2).filter(function (element) { return element.length > 0 });
					if(args.length < 1)
						serveError(rep, 403, 'Access denied');
					else {
						switch(req.method) {
							case 'GET':		db.select(req, rep, args); break;
							case 'POST':	db.insert(req, rep, args); break;
							case 'PUT':		db.update(req, rep, args); break;
							case 'DELETE':	db.remove(req, rep, args); break;
							default:		db.error(rep, 405, 'Method not allowed');
						}
					}
			} else {	
				serveError(rep, 403, 'Access denied');
			}
		}
	}
).listen(listeningPort);

if(debugLog) console.log('Listening on port ' + listeningPort);