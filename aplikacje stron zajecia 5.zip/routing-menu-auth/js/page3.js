app.controller('Page3', ['$http',
	function($http) {	
		var self = this;
		console.log('Page 3 controller started');
	}
]);