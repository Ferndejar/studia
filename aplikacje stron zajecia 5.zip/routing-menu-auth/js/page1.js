app.controller('Page1', ['$http',
	function($http) {	
		var self = this;
		console.log('Page 1 controller started');
	}
]);