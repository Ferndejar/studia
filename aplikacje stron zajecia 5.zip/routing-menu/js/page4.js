app.controller('Page4', ['$http',
	function($http) {	
		var self = this;
		console.log('Page 4 controller started');
	}
]);