app.controller('Projects', ['$http', 'common',
	function($http, common) {	
	
		console.log('Projects controller started');
		
		var self = this;
		self.confirm = common.confirm;
		
		
		
		self.project= {};		
		
		self.refresh = function() {
			$http.get('/db/projects/').then(
				function(response) {
					self.project = response.data;
				},
				function(errResponse) {
					self.project = [];
				}
			);
		}
		
		self.refresh();
		
		self.insert = function() {
			console.log('ctrl.insert(), ' + self.project);
			$http.post('/db/projects/json', self.project).then(
				function(response) {
					self.refresh();
				},
				function(errResponse) {
					console.log(JSON.stringify(errResponse));
				}
			);
		}

		self.edit = function(id = '') {
			if(id) {
				$http.get('/db/projects/' + id).then(
					function(response) {
						self.project = response.data[0];
						$("#editProject").modal();			
					},
					function(errResponse) {}
				);
			} else {
				self.project = {};
				$("#editProject").modal();
			}
		}
		
		self.editSubmit = function() {
			console.log('ctrl.editSubmit(), ' + self.project);
			if(self.project._id) {
				$http.put('/db/projects/' + self.project._id, self.project).then(
					function(response) {
						self.refresh();
					},
					function(errResponse) {
						console.log(JSON.stringify(errResponse));
					}
				);
			} else {
				$http.post('/db/projects/json', self.project).then(
					function(response) {
						self.refresh();
					},
					function(errResponse) {
						console.log(JSON.stringify(errResponse));
					}
				);				
			}
			$('#editProject').modal('hide');
		}

		self.confirmRemove = function(project) {
			$('#editProject').modal('hide');
			common.confirm.text = 'Are you sure to delete a project "' + self.project.firstName + ' ' + self.project.lastName + '" ?';
			common.confirm.action = self.remove;
			$("#confirmDialog").modal();
		}
		
		self.remove = function() {
			$("#confirmDialog").modal('hide');
			if(self.project._id) {
				$http.delete('/db/projects/' + self.project._id).then(
					function(response) {
						self.refresh();
					},
					function(errResponse) {
						console.log(JSON.stringify(errResponse));
					}
				);
				$('#editProject').modal('hide');
			}
		}
	}
]);