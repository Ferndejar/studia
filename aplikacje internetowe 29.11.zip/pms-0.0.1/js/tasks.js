app.controller('Tasks', ['$http', 'common',
	function($http, common) {	
	
		console.log('Tasks controller started');
		
		var self = this;
		self.confirm = common.confirm;
	}
]);