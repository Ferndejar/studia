var fs = require('fs');
var http = require('http');
var path = require('path');
var mime = require('mime');

var debugLog = true;
var initDB = true; // set to false to suppress DB initialization

function serveFile(rep, fileName, errorCode, message) {
	
	if(debugLog) console.log('Serving file ' + fileName + (message ? ' with message \'' + message + '\'': ''));
	
    fs.readFile(fileName, function(err, data) {
		if(err) {
            serveError(rep, 404, 'Document ' + fileName + ' not found');
        } else {
			rep.writeHead(errorCode, message, { 'Content-Type': mime.lookup(path.basename(fileName)) });
			if(message) {
				data = data.toString().replace('{errMsg}', rep.statusMessage).replace('{errCode}', rep.statusCode);
			}
			rep.end(data);
        }
      });
}

function serveError(rep, error, message) {
	serveFile(rep, 'html/error.html', error, message);
}

var db = require('./db.js');

if(initDB) {
	require('./initialize.js');
}

var listeningPort = 8888;

http.createServer().on('request', function (req, rep) {
	
	if(debugLog) console.log('HTTP request URL: ' + req.url);
	
	switch(req.url) {
		case '/':
			serveFile(rep, 'html/index.html', 200, '');
			break;
		case '/favicon.ico':
			serveFile(rep, 'img/favicon.ico', 200, '');
			break;
		default:
			if(/^\/(html|css|js|fonts|img)\//.test(req.url)) {
				var fileName = path.normalize('./' + req.url)
				serveFile(rep, fileName, 200, '');
			} else if(/^\/db\//.test(req.url)) {
					db.serve(req, rep, 'persons');
			} else {	
				serveError(rep, 403, 'Access denied');
			}
		}
	}
).listen(listeningPort);